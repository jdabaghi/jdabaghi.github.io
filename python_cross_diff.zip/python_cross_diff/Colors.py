#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 20 15:55:22 2022

@author: carnot-smiles
"""
import numpy as np
#### Colors####

#gold_color = 1/255 * (255, 215, 0);
#brown_color = (139, 69, 19);
#indigo_color = (75, 0, 130);
midnight_blue = 1.0/255.0 * np.array([25, 25, 112, 255]);
#forest_green = (34, 139, 34);
dark_green = 1.0/255.0 * np.array([0, 100, 0]);
#slate_blue = (106, 90, 205);
#DeepPink2 = (238, 18, 137);
#LightSalmon4 = (139, 87, 66);
#MediumVioletRed = (199, 21, 133);
#green4	= (0, 139, 0);
#azure4 = (131, 139, 139);
RoyalBlue1 = 1.0/255.0 * np.array([72, 118, 255]);
OrangeRed2 = 1.0/255.0 * np.array([238, 64, 0]);
#gold3 =	(205, 173, 0);
MediumOrchid3 = 1.0/255.0 * np.array([180, 82, 205]);
#HotPink3 = (205, 96, 144);
black =  1.0/255.0 * np.array([0, 0, 0]);
DarkOrange2 = 1.0/255.0 * np.array([238, 118, 0]);