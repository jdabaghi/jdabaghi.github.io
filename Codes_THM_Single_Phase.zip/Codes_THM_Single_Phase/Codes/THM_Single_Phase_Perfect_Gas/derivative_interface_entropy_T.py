# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 12:15:22 2025

@author: mmohamad2023
"""

import numpy as np

#T_ref = 300/300
#rho_c=0.08080594274535273

rho_c = 1
Cf = 1e3/rho_c
#T_ref = 300

## Weakly Compressible

# def derivative_interface_entropy_T(T):
    
#     result = Cf/(2*T) 
#     return result

##Perfect Gas

def derivative_interface_entropy_T(T):
    
    result = Cf/(2*T) 
    return result