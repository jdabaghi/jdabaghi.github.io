# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 14:00:48 2025

@author: mmohamad2023
"""

import numpy as np

rho_c=1
Rg=8.3149*rho_c 
rho_ref = 1e3/rho_c

## Weakly Compressible

# def derivative_interface_entropy_p(p):
    
#     result = -(1/rho_ref)/(2*p) 
#     return result

#"Perfect Gas

def derivative_interface_entropy_p(p):
    
    result = -(Rg)/(2*p) 
    return result