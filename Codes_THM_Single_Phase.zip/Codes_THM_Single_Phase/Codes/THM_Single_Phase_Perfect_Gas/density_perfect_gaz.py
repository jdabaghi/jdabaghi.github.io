# -*- coding: utf-8 -*-
"""
Created on Wed May  7 15:39:18 2025

@author: mmohamad2023
"""


import numpy as np

P_c = 1e5
T_c=300
rho_c=1
M_H2 = 2.01568e-3                                 #Molar mass
Rg=8.3149*rho_c
T_ref=300/T_c


# P_c=1
# T_c=1
# rho_c=1
# M_H2 = 2.01568e-3                                #Molar mass
# Rg=8.3149*rho_c
# T_ref=300/T_c

def interface_density(p_K, p_L):
    
    if p_K-p_L==0:     
        return ((M_H2*P_c/(Rg*T_ref*T_c))*(p_K))
    else:
        numerator = p_K - p_L
        denominator = (M_H2*P_c/(2*Rg*T_ref*T_c))*(p_K**2 - p_L**2)
        return numerator / denominator