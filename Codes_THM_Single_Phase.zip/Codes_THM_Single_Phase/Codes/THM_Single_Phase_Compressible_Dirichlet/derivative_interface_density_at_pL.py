# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 11:52:06 2025

@author: mmohamad2023
"""

import numpy as np

rho_ref = 1e3/1e3
C_ref = 1e-6*1e5
p_ref=1e5/1e5

# rho_ref = 1e3/1
# C_ref = 1e-6
# p_ref=1e5/1

def derivative_interface_density_at_pL(p_K, p_L):
    
    if (np.log(abs(rho_ref*(1+C_ref*(p_K-p_ref)))) - np.log(abs(rho_ref*(1+C_ref*(p_L-p_ref)))))== 0:  
        return 0
    else:
        numerator = -((np.log(abs(rho_ref*(1+C_ref*(p_K-p_ref)))) - np.log(abs(rho_ref*(1+C_ref*(p_L-p_ref)))))/(rho_ref*C_ref))-(1/(abs(rho_ref*(1+C_ref*(p_L-p_ref)))))*(p_K - p_L)
        denominator = ((np.log(abs(rho_ref*(1+C_ref*(p_K-p_ref)))) - np.log(abs(rho_ref*(1+C_ref*(p_L-p_ref)))))/(rho_ref*C_ref))**2
        return numerator / denominator