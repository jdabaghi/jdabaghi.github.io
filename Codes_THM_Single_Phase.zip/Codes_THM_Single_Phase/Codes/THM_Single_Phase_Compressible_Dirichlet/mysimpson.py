# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 16:43:26 2024

@author: Hp
"""

def mysimpson(first_value, intern_value, end_value, Dx):
    result = Dx/6 * (first_value + 4 * intern_value + end_value);
    return result
    