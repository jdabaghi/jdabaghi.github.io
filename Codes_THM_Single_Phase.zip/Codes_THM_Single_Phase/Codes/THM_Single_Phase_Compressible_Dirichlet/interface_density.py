# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 17:48:59 2025

@author: mmohamad2023
"""

import numpy as np

#Nondimensionable

rho_ref = 1e3/1e3
C_ref = 1e-6*1e5
p_ref=1e5/1e5

#dimensiable

# rho_ref = 1e3/1
# C_ref = 1e-6
# p_ref=1e5/1


def interface_density(p_K, p_L):
    
    if (np.log(abs(rho_ref*(1+C_ref*(p_K-p_ref)))) - np.log(abs(rho_ref*(1+C_ref*(p_L-p_ref)))))==0:     
        return (rho_ref*(1+C_ref*(p_K-p_ref)))
    else:
        numerator = p_K - p_L
        denominator = (np.log(abs(rho_ref*(1+C_ref*(p_K-p_ref)))) - np.log(abs(rho_ref*(1+C_ref*(p_L-p_ref)))))/(rho_ref*C_ref)
        return numerator / denominator