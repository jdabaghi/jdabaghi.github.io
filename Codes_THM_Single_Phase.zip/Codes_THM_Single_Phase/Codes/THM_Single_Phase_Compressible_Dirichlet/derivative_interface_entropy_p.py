# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 14:00:48 2025

@author: mmohamad2023
"""

import numpy as np
#T_ref = 300/300
rho_ref = 1e3/1e3
# rho_c=0.08080594274535273
# Rg=8.3149*rho_c 
#T_ref = 300

def derivative_interface_entropy_p(p):
    
    result = -(1/rho_ref)/(2*p) 
    return result