# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 18:04:14 2025

@author: mmohamad2023
"""

import numpy as np

T_ref = 300/300
p_ref = 1e5/1e5
#rho_c=0.08080594274535273   # for perfect gas
rho_c=1e3   # for weakly compressible
Cf = 1e3/rho_c
rho_ref = 1e3/rho_c
Rg=8.3149*rho_c 
#T_ref = 300

# entropy depending only on T : s(T) = ln (T/T_ref)

#Incompressible

def interface_entropy(T_K, T_L):
    
    result = (np.log(abs(T_K/T_ref))+np.log(abs(T_L/T_ref)))/2 
    return result


# entropy depending on T and p : s(p,T) = C_f ln (T/T_ref) - C_p ln (p/p_ref)

# def interface_entropy(T_K, T_L, p_K, p_L):
# # #     # perfect gas
# # #     #result = (Cf*np.log(T_K/T_ref)-(Rg)*np.log(p_K/p_ref)+Cf*np.log(T_L/T_ref)-(Rg)*np.log(p_L/p_ref))/2
    
# #     # weakly compressible
#       result = (Cf*np.log(T_K/T_ref)-(1/rho_ref)*np.log(p_K/p_ref)+Cf*np.log(T_L/T_ref)-(1/rho_ref)*np.log(p_L/p_ref))/2
#       return result



# def derivative_interface_entropy_T(T):
    
#     result = 1/(2*T) 
#     return result

