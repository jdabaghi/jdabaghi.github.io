# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 12:15:22 2025

@author: mmohamad2023
"""

import numpy as np

T_ref = 300/300

#T_ref = 300/1

def derivative_interface_entropy_TK(T_K, T_L):
    
    result = 1/(2*T_K) 
    return result