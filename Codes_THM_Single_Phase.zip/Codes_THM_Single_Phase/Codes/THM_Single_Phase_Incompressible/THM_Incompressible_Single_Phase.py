# -*- coding: utf-8 -*-
"""
Created on Wed May  7 14:03:05 2025

@author: mmohamad2023
"""



#1d Incompressible THM model using cell-centered FVM for space discretisation (type TPFA)
# and backward Euler for time discretisation with Dirichlet boundary conditions
# the system of equations is :
# 1st eq : \partial_t( \rho \phi) - \frac{K}{\mu} \partial_x(\rho \partial_x p) = h_m
# 2nd eq : T \partial_t(S_s) + \partial_t(\rho \phi s) T - \frac{K}{mu} \partial_x(\rho s \partial_x p) T 
#            - \frac{\lambda T}{T_ref} \partial_{xx} T = h_e  
#3rd eq : m_0 \partial_{tt} u -\frac{E(1-\nu)}{(1+\nu)(1-2\nu)}\partial_{xx} u + b \partial_x p + 3*alpha_s*K_s*\partial_x T = h

import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.linalg as la
import mysimpson
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from scipy.sparse.linalg import gmres
from scipy.sparse.linalg import spilu
import os
from matplotlib.animation import FuncAnimation
import time
import pickle
from scipy.sparse import spdiags
from scipy.sparse import csr_matrix
#import interface_density
import interface_entropy
# import derivative_interface_density_at_pK
# import derivative_interface_density_at_pL
import derivative_interface_entropy_TK
import derivative_interface_entropy_TL 
start = time.time()


#Carachteristics Coefficients (for Nondimensionalisation)

t_c=1
L_c=1
P_c=1e5
T_c =300
u_c=L_c
alpha_c=1/T_c
K_c=1e-10 
lambda_c = 2
rho_c=1e3
C_c=1e6
#mu_c=P_c*t_c
mu_c = 1e-3

#### We can take them one to go back to the original model

# t_c=1
# L_c=1
# P_c=1
# T_c =1
# u_c=L_c
# alpha_c=1/T_c
# K_c=1
# lambda_c = 1
# rho_c=1
# C_c=1
# mu_c=1

#parameters 

alpha_s=1.5*1e-5/alpha_c                              # Volumetric skeleton thermal dilatation coefficient
b=0.65                                                # Biot's Coefficient
phi_0 = 0.2                                           # Initial porosity
K = 1.0*1e-10 /K_c                                    # Permeability
Lambda = 2 /lambda_c                                  # Thermal conductivity
mu = 1e-3 /(mu_c)                                     # Viscosity of the fluid
nu=0.15                                               # Poisson Coefficient
E=40*1e9 /P_c                                         # Young Modulus
K_s= ((E*P_c)/(3*(1-2*nu)))/P_c                       # Bulk Modulus
N = ((K_s*P_c)/((b-phi_0)*(1-b)) ) /P_c               # Biot modulus
rho_ref = 1e3 /rho_c                                  # Density
C_s = 2*1e6 /C_c                                      # Skeleton volumetric heat capacity
T_ref = 300.0 /T_c                                    # Reference temperature
p_ref=1e5 /P_c                                        # Reference Pressure
alpha_phi = ((b-phi_0)*(alpha_s*alpha_c)) /alpha_c    # volumetric thermal dilatation coefficient
m_0=0                                                 # Average fluid skeleton specific density



#### nondimension parameters

r1_c = (K_c*P_c*t_c)/(mu_c*(L_c**2))
r2_c = (C_c)/(alpha_c*P_c)
r3_c = (rho_c)/(alpha_c*P_c)
r4_c = (K_c*rho_c*t_c)/(alpha_c*mu_c*(L_c**2))
r5_c = (lambda_c*t_c)/(alpha_c*P_c*(L_c**2))
r6_c = alpha_c*T_c

directory2 = "images_THM_Incompressible_Single_Phase"
os.system("mkdir -p " + directory2)

#Space discretisation 

L = L_c                                          # lenght of the domain
Nx = 50                                         # Number of cells
dx = (L/L_c)/Nx                                   # spatial step
space_mesh = np.arange(0, (L/L_c) + dx, dx);     
x=np.zeros((len(space_mesh) - 1))                 # cell centers
for i in range(0,len((space_mesh)) - 1):
 x[i]=1/2 *(space_mesh[i] + space_mesh[i + 1])


#Time discretisation
  
T_max = t_c                                    # Total simulation time
dt = 2*1e-3                                     # Time step
Nt = int((T_max/t_c) / dt)                      # Number of time steps
t=np.arange(0, (T_max/t_c)+dt, dt)

#Exact solutions

def exact_T(x,t):
    u= (T_ref*T_c - np.exp(-t)* np.sin(np.pi*x))/T_c
    return u

def exact_p(x,t):
    v = (np.exp(-t)*np.sin(np.pi*x) +p_ref*P_c)/P_c
    
    return v

def exact_u(x,t):
    # w=0
    w=1e-4*np.exp(-t)*x*(x-L/L_c)/u_c
    return w


#Initial conditions

def T_initial(x):
   # z=T_ref                                        # without exact solution
    z = (T_ref*T_c - np.sin(np.pi*x))/T_c           # with exact solution
    
    return z 

def p_initial(x):
   # s=p_ref                                        # without exact solution
    s = (np.sin(np.pi*x) +p_ref*P_c)/P_c            # with exact solution
    
    return s

def u_initial(x):
  #  n=1e-5                                         # without exact solution
    n= 1e-4*x*(x-L/L_c)/u_c                         # with exact solution
    return n


#porosity function

def phi(x,t):
    l = phi_0 - b*u_c*1e-4*(2*x-L/L_c)/(L_c*u_c) +3*alpha_phi*alpha_c*T_c*T_initial(x) - p_initial(x)/(N) + b*u_c*1e-4*np.exp(-t)*(2*x-L/L_c)/(L_c*u_c) -3*alpha_phi*alpha_c*T_c*exact_T(x,t)+exact_p(x,t)/(N)
  #  l = phi_0  +3*alpha_phi*alpha_c*T_initial(x) - p_initial(x)/(N)  -3*alpha_phi*alpha_c*exact_T(x,t)+exact_p(x,t)/(N)
    return l


# #Source terms with exact solution

def h_m(x,t):    
    result = ((rho_c)/(t_c))*(rho_ref*(-b*1e-4*(2*x-L/L_c)*np.exp(-t)/u_c -3*alpha_phi*np.exp(-t)*np.sin(np.pi*x)/T_c- np.exp(-t)*np.sin(np.pi*x)/(N*P_c)) + r1_c*rho_ref*K*(np.pi**2)*np.exp(-t)*np.sin(np.pi*x)/(mu*P_c) )
    return result

def h_e(x,t):
    result = ((alpha_c*T_c*P_c*exact_T(x, t))/(t_c))*(-np.exp(-t)*3*alpha_s*K_s*1e-4*(2*x-L/L_c)/u_c + 3*alpha_phi*np.exp(-t)*np.sin(np.pi*x)/P_c + r2_c*C_s*(np.exp(-t)*np.sin(np.pi*x))/(T_ref*T_c) + r3_c*rho_ref*phi(x, t)*(np.exp(-t)*np.sin(np.pi*x))/(T_c*exact_T(x, t))+r3_c*np.log((exact_T(x, t)/T_ref))*((rho_ref*(-b*1e-4*(2*x-L/L_c)*np.exp(-t)/u_c -3*alpha_phi*np.exp(-t)*np.sin(np.pi*x)/T_c- np.exp(-t)*np.sin(np.pi*x)/(N*P_c)) )) +r4_c* np.exp(-2*t)*rho_ref*K*(np.pi**2*(np.cos(np.pi*x))**2)/(mu*P_c*T_c*exact_T(x, t)) +r4_c*np.log((exact_T(x, t)/T_ref))*(rho_ref*K*(np.pi**2)*np.exp(-t)*np.sin(np.pi*x)/(mu*P_c) ) - r5_c*Lambda*np.pi**2*np.exp(-t)*np.sin(np.pi*x)/(T_ref*T_c))  
    return result

def h(x,t):
    result = ((P_c)/(L_c))*(-(E*(1-nu))*2*1e-4*np.exp(-t)/((1+nu)*(1-2*nu))/u_c + b*np.pi*np.exp(-t)*np.cos(np.pi*x)/P_c -r6_c*3*alpha_s*K_s*np.pi*np.exp(-t)*np.cos(np.pi*x)/T_c)
    return result

## source terms without exact solution

# def h_m(x,t):
#     result=0
#     return result

# def h_e(x,t):
#     result=0
#     return result

# def h(x,t):
#     result=0
#     return result

#Boundary Conditions
#Atx=0
p_0=1e5/P_c
T_0=300/T_c

#At x=L
p_f=1e5/P_c
T_f=300/T_c

#Temperature, pressure and displacement

T = np.zeros((len(x),len(t)))
p = np.zeros((len(x),len(t)))
u = np.zeros((len(x),len(t)))

#Initial solutions

T[:,0] = T_initial(x)
p[:,0] = p_initial(x)
u[:,0] = u_initial(x)

T_old = T[:,0]
p_old = p[:,0]
u_old = u[:,0]


#Newton Raphson parameters

tol=1e-8
max_iter_newton = 100

#loop on time

for nn in range (0, len(t)-1):
    T_new = T[:,nn]
    p_new = p[:,nn]
    u_new = u[:,nn]
    
    p_old = p[:, nn]
    T_old = T[:,nn]
    u_old = u[:,nn]
   
    converged = False #Track convergence
    
    norm_newton_error = np.zeros(max_iter_newton)
    
    for iter in range(max_iter_newton):
        #The residuals
        R1 = np.zeros(len(x))
        R2 = np.zeros(len(x))  
        R3 = np.zeros(len(x))
# Initialize lists to store non-zero values and their indices for the Jacobian
        row_indices = []
        col_indices = []
        values = []   
         
       #R1 = (\rho_K^n \phi_K^n -\rho_K^{n-1} \phi_K^{n-1} )/dt + \sum_L(-\rho_KL (K/mu)(p_L-p_K))/(dx^2) - h_m_K^n
       
        R1[0] = ((rho_ref)*(phi_0 + b*(u_new[1]-u_initial(x[1]))/(((3/2))*dx) -3*alpha_phi*(T_new[0]-T_initial(x[0])) +(p_new[0]- p_initial(x[0]))/(N) )-(rho_ref)*(phi_0 + b*(u_old[1]-u_initial(x[1]))/(((3/2))*dx) -3*alpha_phi*(T_old[0]-T_initial(x[0])) +(p_old[0]- p_initial(x[0]))/(N)))/dt + r1_c*(-rho_ref*K*(p_new[1]-p_new[0]))/(mu*(dx**2))+r1_c*(-rho_ref*K*2*(p_0-p_new[0]))/(mu*(dx**2)) -(t_c/rho_c)*h_m(x[0], t[nn+1])
        R1[len(x)-1]=((rho_ref)*(phi_0 + b*(-u_new[len(x)-2]+u_initial(x[len(x)-2]))/(((3/2))*dx) -3*alpha_phi*(T_new[len(x)-1]-T_initial(x[len(x)-1])) +(p_new[len(x)-1]- p_initial(x[len(x)-1]))/(N) )-(rho_ref)*(phi_0 + b*(-u_old[len(x)-2]+u_initial(x[len(x)-2]))/(((3/2))*dx) -3*alpha_phi*(T_old[len(x)-1]-T_initial(x[len(x)-1])) +(p_old[len(x)-1]- p_initial(x[len(x)-1]))/(N)))/dt + r1_c*(-rho_ref*K*(p_new[len(x)-2]-p_new[len(x)-1]))/(mu*(dx**2))+r1_c*(-rho_ref*2*K*(p_f-p_new[len(x)-1]))/(mu*(dx**2)) - (t_c/rho_c)*h_m(x[len(x)-1], t[nn+1])

       #R2 = (S_s,K^n - S_s,K^{n-1})/dt + (\rho_K^n\phi_K^ns_K^n - \rho_K^{n-1}\phi_K^{n-1}s_K^{n-1})/dt +\sum_L(-\rho_{KL}s_{KL}(K/mu)(p_L-p_K)-(lambda/T_ref)(T_L-T_K))/(dx**2) - h_e,K^n/T_K^n
       
        R2[0] = 3*alpha_s*K_s*(u_new[1]-u_old[1])/((3/2)*dt*dx) -3*alpha_phi*(p_new[0]-p_old[0])/dt +r2_c*C_s*(T_new[0]-T_old[0])/(dt*T_ref) +r3_c* ((rho_ref)*(phi_0 + b*(u_new[1]-u_initial(x[1]))/(((3/2))*dx) -3*alpha_phi*(T_new[0]-T_initial(x[0])) +(p_new[0]- p_initial(x[0]))/(N))*(np.log(abs(T_new[0]/T_ref)))-(rho_ref)*(phi_0 + b*(u_old[1]-u_initial(x[1]))/(((3/2))*dx) -3*alpha_phi*(T_old[0]-T_initial(x[0])) +(p_old[0]- p_initial(x[0]))/(N))*(np.log(abs(T_old[0]/T_ref))))/dt +r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[0], T_new[1])*K*(p_new[1]-p_new[0]))+(-rho_ref*interface_entropy.interface_entropy(T_new[0], T_0)*K*2*(p_0-p_new[0])))/(mu*(dx**2))+r5_c*((-Lambda*(T_new[1]-T_new[0]))+(-Lambda*2*(T_0-T_new[0])))/(T_ref*(dx**2)) -((t_c)/(alpha_c*P_c*T_c))*(h_e(x[0], t[nn+1])/T_new[0])              
        R2[len(x)-1] =3*alpha_s*K_s*(-u_new[len(x)-2]+u_old[len(x)-2])/((3/2)*dt*dx) -3*alpha_phi*(p_new[len(x)-1]-p_old[len(x)-1])/dt +r2_c*C_s*(T_new[len(x)-1]-T_old[len(x)-1])/(dt*T_ref) + r3_c*((rho_ref)*(phi_0 + b*(-u_new[len(x)-2]+u_initial(x[len(x)-2]))/(((3/2))*dx) -3*alpha_phi*(T_new[len(x)-1]-T_initial(x[len(x)-1])) +(p_new[len(x)-1]- p_initial(x[len(x)-1]))/(N))*(np.log(abs(T_new[len(x)-1]/T_ref)))-(rho_ref)*(phi_0 + b*(-u_old[len(x)-2]+u_initial(x[len(x)-2]))/(((3/2))*dx) -3*alpha_phi*(T_old[len(x)-1]-T_initial(x[len(x)-1])) +(p_old[len(x)-1]- p_initial(x[len(x)-1]))/(N))*(np.log(abs(T_old[len(x)-1]/T_ref))))/dt +r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[len(x)-1], T_new[len(x)-2])*K*(p_new[len(x)-2]-p_new[len(x)-1]))+(-rho_ref*interface_entropy.interface_entropy(T_new[len(x)-1], T_f)*2*K*(p_f-p_new[len(x)-1])))/(mu*(dx**2))+r5_c*((-Lambda*(T_new[len(x)-2]-T_new[len(x)-1]))+(-Lambda*2*(T_f-T_new[len(x)-1])))/(T_ref*(dx**2)) -((t_c)/(alpha_c*P_c*T_c))*(h_e(x[len(x)-1], t[nn+1])/T_new[len(x)-1])              
     
        #R3 = -(E*(1-nu))/((1+nu)*(1-2*nu)) \sum_L (u_L-u_K)/dx**2 +b \sum_L p_KL n_KL +3*alpha_sK_s T_KL n_KL -h_K^n
        
        R3[0] = -(E*(1-nu))*(u_new[1]-3*u_new[0])/(dx**2*(1+nu)*(1-2*nu)) + b*(p_new[1]-p_0)/(((3/2))*dx) +r6_c* 3*alpha_s*K_s*(T_new[1]-T_0)/(((3/2))*dx) - ((L_c)/(P_c))*h(x[0],t[nn+1])
        R3[len(x)-1] =  -(E*(1-nu))*(u_new[len(x)-2]-3*u_new[len(x)-1])/(dx**2*(1+nu)*(1-2*nu)) + b*(p_f-p_new[len(x)-2])/(((3/2))*dx) + r6_c*3*alpha_s*K_s*(T_f-T_new[len(x)-2])/(((3/2))*dx) - ((L_c)/(P_c))*h(x[len(x)-1],t[nn+1])
        
       
        #Jacobien
        
# First row R1
        #R10/T0
        
        row_indices.append(0)
        col_indices.append(0)
        values.append(-(rho_ref)*3*alpha_phi/dt )
        
        #R10/P0
         
        row_indices.append(0)
        col_indices.append(len(x))
        values.append((rho_ref)/(N*dt)+ r1_c*(-rho_ref*K*(-1))/(mu*(dx**2)) +r1_c*(-rho_ref*K*2*(-1))/(mu*(dx**2)))
        
        #R10/P1
        
        row_indices.append(0)
        col_indices.append(len(x)+1)
        values.append(r1_c*(-rho_ref*K*(1))/(mu*(dx**2)))
        
        #R10/u1
        
        row_indices.append(0)
        col_indices.append(2*len(x)+1)
        values.append((rho_ref)*b/(((3/2))*dx*dt))
        
        
#First Row R2
        #R20/T0
        
        row_indices.append(len(x))
        col_indices.append(0)
        values.append((r2_c*C_s)/(dt*T_ref)-r3_c*(rho_ref)*3*alpha_phi*(np.log(abs(T_new[0]/T_ref)))/dt+r3_c*(rho_ref)*(phi_0 + b*(u_new[1]-u_initial(x[1]))/(((3/2))*dx) -3*alpha_phi*(T_new[0]-T_initial(x[0])) +(p_new[0]- p_initial(x[0]))/(N))*(1/T_new[0])/dt
                      +r4_c*((-rho_ref*derivative_interface_entropy_TK.derivative_interface_entropy_TK(T_new[0], T_new[1])*K*(p_new[1]-p_new[0]))+(-rho_ref*derivative_interface_entropy_TK.derivative_interface_entropy_TK(T_new[0], T_0)*K*2*(p_0-p_new[0])))/(mu*(dx**2))
                      +r5_c*((-Lambda*(-1))+(-Lambda*2*(-1)))/(T_ref*(dx**2)) +((t_c)/(alpha_c*P_c*T_c))*(h_e(x[0], t[nn+1])/((T_new[0])**2)))
        
        #R20/T1
        row_indices.append(len(x))
        col_indices.append(1)
        values.append(r4_c*((-rho_ref*derivative_interface_entropy_TL.derivative_interface_entropy_TL(T_new[0], T_new[1])*K*(p_new[1]-p_new[0])))/(mu*(dx**2))+r5_c*((-Lambda*(1)))/(T_ref*(dx**2)))
        
        #R20/p0
        row_indices.append(len(x))
        col_indices.append(len(x))
        values.append( -3*alpha_phi/dt +r3_c*(rho_ref)*(np.log(abs(T_new[0]/T_ref)))/(N*dt) + r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[0], T_new[1])*K*(-1))+(-rho_ref*interface_entropy.interface_entropy(T_new[0], T_0)*2*K*(-1)))/(mu*(dx**2)))
       
        #R20/p1
        row_indices.append(len(x))
        col_indices.append(len(x)+1)
        values.append(r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[0], T_new[1])*K*(1)))/(mu*(dx**2)))
              
        #R20/u1
        row_indices.append(len(x))
        col_indices.append(2*len(x)+1)
        values.append(3*alpha_s*K_s/((3/2)*dt*dx)+r3_c*(rho_ref)*( b*(1)/(((3/2))*dx))*(np.log(abs(T_new[0]/T_ref)))/dt)
        
#First Row R3
       
        #R30/p1
        row_indices.append(2*len(x))
        col_indices.append(len(x)+1)
        values.append(b/((3/2)*dx))
        
        
        #R30/T1
        row_indices.append(2*len(x))
        col_indices.append(1)
        values.append(r6_c*3*alpha_s*K_s/((3/2)*dx))
        
        #R30/u0
        row_indices.append(2*len(x))
        col_indices.append(2*len(x))
        values.append(3*(E*(1-nu))/(dx**2*(1+nu)*(1-2*nu)))
        
        #R30/u1
        row_indices.append(2*len(x))
        col_indices.append(2*len(x)+1)
        values.append(-(E*(1-nu))/(dx**2*(1+nu)*(1-2*nu)))
        
        
# Last row R1

        #R1N/TN
        
        row_indices.append(len(x)-1)
        col_indices.append(len(x)-1)
        values.append(-(rho_ref)*3*alpha_phi/dt)
        
         #R1N/p_{N-1}
         
        row_indices.append(len(x)-1)
        col_indices.append(2*len(x)-2)
        values.append(r1_c*(-rho_ref*K*(1))/(mu*(dx**2)))   
        
        #R1N/pN
        
        row_indices.append(len(x)-1)
        col_indices.append(2*len(x)-1)
        values.append((rho_ref)/(N*dt)+r1_c*(-rho_ref*K*(-1))/(mu*(dx**2))+r1_c*(-rho_ref*K*2*(-1))/(mu*(dx**2)))
        
        #R1N/u_{N-1}
        
        row_indices.append(len(x)-1)
        col_indices.append(3*len(x)-2)
        values.append(-(rho_ref)*b/(((3/2))*dx*dt))
        
    #Last Row R2
    
        #R2N/T_{N-1}
        row_indices.append(2*len(x)-1)
        col_indices.append(len(x)-2)
        values.append(r4_c*((-rho_ref*derivative_interface_entropy_TL.derivative_interface_entropy_TL(T_new[len(x)-1], T_new[len(x)-2])*K*(p_new[len(x)-2]-p_new[len(x)-1])))/(mu*(dx**2))+r5_c*((-Lambda*(1)))/(T_ref*(dx**2)))
            
        #R2N/TN
        row_indices.append(2*len(x)-1)
        col_indices.append(len(x)-1)
        values.append((r2_c*C_s)/(dt*T_ref)-r3_c*(rho_ref)*3*alpha_phi*(np.log(abs(T_new[len(x)-1]/T_ref)))/dt+r3_c*(rho_ref)*(phi_0 + b*(-u_new[len(x)-2]+u_initial(x[len(x)-2]))/(((3/2))*dx) -3*alpha_phi*(T_new[len(x)-1]-T_initial(x[len(x)-1])) +(p_new[len(x)-1]- p_initial(x[len(x)-1]))/(N))*(1/T_new[len(x)-1])/dt+r4_c*((-rho_ref*derivative_interface_entropy_TK.derivative_interface_entropy_TK(T_new[len(x)-1], T_new[len(x)-2])*K*(p_new[len(x)-2]-p_new[len(x)-1]))+(-rho_ref*derivative_interface_entropy_TK.derivative_interface_entropy_TK(T_new[len(x)-1], T_f)*K*2*(p_f-p_new[len(x)-1])))/(mu*(dx**2))+r5_c*((-Lambda*(-1))+(-Lambda*2*(-1)))/(T_ref*(dx**2)) +((t_c)/(alpha_c*P_c*T_c))*(h_e(x[len(x)-1], t[nn+1])/(T_new[len(x)-1]**2)))
         
       
        #R2N/pN
        row_indices.append(2*len(x)-1)
        col_indices.append(2*len(x)-1)
        values.append( -3*alpha_phi/dt  +r3_c*(rho_ref)*(np.log(abs(T_new[len(x)-1]/T_ref)))/(N*dt)+r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[len(x)-1], T_new[len(x)-2])*K*(-1))+(-rho_ref*interface_entropy.interface_entropy(T_new[len(x)-1], T_f)*K*2*(-1)))/(mu*(dx**2)))
        
        #R2N/p_{N-1}
        row_indices.append(2*len(x)-1)
        col_indices.append(2*len(x)-2)
        values.append(r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[len(x)-1], T_new[len(x)-2])*K*(1)))/(mu*(dx**2)))
        
        #R2N/u_{N-1}
        
        row_indices.append(2*len(x)-1)
        col_indices.append(3*len(x)-2)
        values.append(-3*alpha_s*K_s/((3/2)*dt*dx)+r3_c*(rho_ref)*( b*(-1)/(((3/2))*dx))*(np.log(abs(T_new[len(x)-1]/T_ref)))/dt)
        
        
#Last Row R3
       
        #R3N/p_{N-1}
        row_indices.append(3*len(x)-1)
        col_indices.append(2*len(x)-2)
        values.append(-b/((3/2)*dx))
        
        
        #R3N/T_{N-1}
        row_indices.append(3*len(x)-1)
        col_indices.append(len(x)-2)
        values.append(-r6_c*3*alpha_s*K_s/((3/2)*dx))
        
        #R3N/uN
        row_indices.append(3*len(x)-1)
        col_indices.append(3*len(x)-1)
        values.append(3*(E*(1-nu))/(dx**2*(1+nu)*(1-2*nu)))
        
        #R3N/u_{N-1}
        row_indices.append(3*len(x)-1)
        col_indices.append(3*len(x)-2)
        values.append(-(E*(1-nu))/(dx**2*(1+nu)*(1-2*nu)))
        
        for ii in range(1, len(x)-1):
            
            #R1 = (\rho_K^n \phi_K^n -\rho_K^{n-1} \phi_K^{n-1} )/dt + \sum_L(-\rho_KL (K/mu)(p_L-p_K))/(dx^2) - h_m_K^n
            
            R1[ii] = ((rho_ref)*(phi_0 + b*(u_new[ii+1]-u_new[ii-1]-u_initial(x[ii+1])+u_initial(x[ii-1]))/(2*dx) -3*alpha_phi*(T_new[ii]-T_initial(x[ii])) +(p_new[ii]- p_initial(x[ii]))/(N) )-(rho_ref)*(phi_0 + b*(u_old[ii+1]-u_old[ii-1]-u_initial(x[ii+1])+u_initial(x[ii-1]))/(2*dx) -3*alpha_phi*(T_old[ii]-T_initial(x[ii])) +(p_old[ii]- p_initial(x[ii]))/(N)))/dt + r1_c*(-rho_ref*K*(p_new[ii+1]-p_new[ii]))/(mu*(dx**2))+r1_c*(-rho_ref*K*(p_new[ii-1]-p_new[ii]))/(mu*(dx**2)) - (t_c/rho_c)*h_m(x[ii], t[nn+1])
        
            #R2 = (S_s,K^n - S_s,K^{n-1})/dt + (\rho_K^n\phi_K^ns_K^n - \rho_K^{n-1}\phi_K^{n-1}s_K^{n-1})/dt +\sum_L(-\rho_{KL}s_{KL}(K/mu)(p_L-p_K)-(lambda/T_ref)(T_L-T_K))/(dx**2) - h_e,K^n/T_K^n
       
            R2[ii] = 3*alpha_s*K_s*(u_new[ii+1]-u_new[ii-1]-u_old[ii+1]+u_old[ii-1])/(2*dt*dx) -3*alpha_phi*(p_new[ii]-p_old[ii])/dt +r2_c*C_s*(T_new[ii]-T_old[ii])/(dt*T_ref) + r3_c*((rho_ref)*(phi_0 + b*(u_new[ii+1]-u_new[ii-1]-u_initial(x[ii+1])+u_initial(x[ii-1]))/(2*dx) -3*alpha_phi*(T_new[ii]-T_initial(x[ii])) +(p_new[ii]- p_initial(x[ii]))/(N))*(np.log(abs(T_new[ii]/T_ref)))-(rho_ref)*(phi_0 + b*(u_old[ii+1]-u_old[ii-1]-u_initial(x[ii+1])+u_initial(x[ii-1]))/(2*dx) -3*alpha_phi*(T_old[ii]-T_initial(x[ii])) +(p_old[ii]- p_initial(x[ii]))/(N))*(np.log(abs(T_old[ii]/T_ref))))/dt +r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[ii], T_new[ii+1])*K*(p_new[ii+1]-p_new[ii]))+(-rho_ref*interface_entropy.interface_entropy(T_new[ii], T_new[ii-1])*K*(p_new[ii-1]-p_new[ii])))/(mu*(dx**2))+r5_c*((-Lambda*(T_new[ii+1]-T_new[ii]))+(-Lambda*(T_new[ii-1]-T_new[ii])))/(T_ref*(dx**2)) -((t_c)/(alpha_c*P_c*T_c))*(h_e(x[ii], t[nn+1])/T_new[ii])              
         
            #R3 = -(E*(1-2*nu)+nu*(1+nu))/((1+nu)*(1-2*nu)) \sum_L (u_L-u_K)/dx**2 +b \sum_L p_KL n_KL +3*alpha_sK_s T_KL n_KL -h_K^n
            
            R3[ii] =  -(E*(1-nu))*(u_new[ii+1]+u_new[ii-1]-2*u_new[ii])/(dx**2*(1+nu)*(1-2*nu)) + b*(p_new[ii+1]-p_new[ii-1])/(2*dx) + r6_c*3*alpha_s*K_s*(T_new[ii+1]-T_new[ii-1])/(2*dx) - ((L_c)/(P_c))*h(x[ii],t[nn+1])
           
            
           
            #Middle Rows R1
            #R1i/Ti
            row_indices.append(ii)
            col_indices.append(ii)
            values.append((rho_ref)*(-3*alpha_phi)/dt)
            
            #R1i/p_{i-1}
            row_indices.append(ii)
            col_indices.append(len(x)+ii-1)
            values.append(r1_c*(-rho_ref*K*(1))/(mu*(dx**2)))
            
           #R1i/pi
            row_indices.append(ii)
            col_indices.append(len(x)+ii)
            values.append((rho_ref)/(N*dt)+r1_c*(-rho_ref*K*(-1))/(mu*(dx**2))+r1_c*(-rho_ref*K*(-1))/(mu*(dx**2)))
            
             #R1i/p_{i+1}
            row_indices.append(ii)
            col_indices.append(len(x)+ii+1)
            values.append(r1_c*(-rho_ref*K*(1))/(mu*(dx**2)) )
            
            #R1i/u_{i-1}
            row_indices.append(ii)
            col_indices.append(2*len(x)+ii-1)
            values.append((rho_ref)*( b*(-1))/(2*dx*dt))
            
            #R1i/u_{i+1}
            row_indices.append(ii)
            col_indices.append(2*len(x)+ii+1)
            values.append((rho_ref)*( b*(1))/(2*dx*dt))
            
            
            #Middle Rows R2
            
            #R2i/T_{i-1}
            row_indices.append(len(x)+ii)
            col_indices.append(ii-1)
            values.append(r4_c*(-rho_ref*derivative_interface_entropy_TL.derivative_interface_entropy_TL(T_new[ii], T_new[ii-1])*K*(p_new[ii-1]-p_new[ii]))/(mu*(dx**2))+r5_c*(-Lambda*(1))/(T_ref*(dx**2)))
            
             #R2i/Ti
            row_indices.append(len(x)+ii)
            col_indices.append(ii)
            values.append((r2_c*C_s)/(dt*T_ref)+r3_c*(rho_ref)*( -3*alpha_phi)*(np.log(abs(T_new[ii]/T_ref)))/dt+ r3_c*(rho_ref)*(phi_0 + b*(u_new[ii+1]-u_new[ii-1]-u_initial(x[ii+1])+u_initial(x[ii-1]))/(2*dx) -3*alpha_phi*(T_new[ii]-T_initial(x[ii])) +(p_new[ii]- p_initial(x[ii]))/(N))*(1/T_new[ii])/dt +r4_c*((-rho_ref*derivative_interface_entropy_TK.derivative_interface_entropy_TK(T_new[ii], T_new[ii+1])*K*(p_new[ii+1]-p_new[ii]))+(-rho_ref*derivative_interface_entropy_TK.derivative_interface_entropy_TK(T_new[ii], T_new[ii-1])*K*(p_new[ii-1]-p_new[ii])))/(mu*(dx**2))+r5_c*((-Lambda*(-1))+(-Lambda*(-1)))/(T_ref*(dx**2)) +((t_c)/(alpha_c*P_c*T_c))*(h_e(x[ii], t[nn+1])/(T_new[ii]**2) ))
            
            #R2i/T_{i+1}
            row_indices.append(len(x)+ii)
            col_indices.append(ii+1)
            values.append(r4_c*(-rho_ref*derivative_interface_entropy_TL.derivative_interface_entropy_TL(T_new[ii], T_new[ii+1])*K*(p_new[ii+1]-p_new[ii]))/(mu*(dx**2))+r5_c*(-Lambda*(1))/(T_ref*(dx**2)))
            
           
           #R2i/pi 
            row_indices.append(len(x)+ii)
            col_indices.append(len(x)+ii)
            values.append(-3*alpha_phi/dt+ r3_c*(rho_ref)*(np.log(abs(T_new[ii]/T_ref)))/(N*dt)+r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[ii], T_new[ii+1])*K*(-1))+(-rho_ref*interface_entropy.interface_entropy(T_new[ii], T_new[ii-1])*K*(-1)))/(mu*(dx**2)))
            
            
             #R2i/p_{i+1}
            row_indices.append(len(x)+ii)
            col_indices.append(len(x)+ii+1)
            values.append(r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[ii], T_new[ii+1])*K*(1)))/(mu*(dx**2)))
            
            
            #R2i/p_{i-1}
            row_indices.append(len(x)+ii)
            col_indices.append(len(x)+ii-1)
            values.append(r4_c*((-rho_ref*interface_entropy.interface_entropy(T_new[ii], T_new[ii-1])*K*(1)))/(mu*(dx**2)) )
            
            
            #R2i/u_{i-1}
            row_indices.append(len(x)+ii)
            col_indices.append(2*len(x)+ii-1)
            values.append(-3*alpha_s*K_s/(2*dt*dx)+r3_c*(rho_ref)*( b*(-1)/(2*dx))*(np.log(abs(T_new[ii]/T_ref)))/dt)
            
            #R2i/u_{i+1}
            row_indices.append(len(x)+ii)
            col_indices.append(2*len(x)+ii+1)
            values.append(3*alpha_s*K_s/(2*dt*dx)+r3_c*(rho_ref)*( b*(1)/(2*dx))*(np.log(abs(T_new[ii]/T_ref)))/dt)
            
            
            #Middle Rows R3
            
            #R3i/T_{ii-1}
            row_indices.append(2*len(x)+ii)
            col_indices.append(ii-1)
            values.append(-r6_c*3*alpha_s*K_s/(2*dx))
            
            #R3i/T_{i+1}
            row_indices.append(2*len(x)+ii)
            col_indices.append(ii+1)
            values.append(r6_c*3*alpha_s*K_s/(2*dx))   
           
           #R3i/p_{i-1}
            row_indices.append(2*len(x)+ii)
            col_indices.append(len(x)+ii-1)
            values.append(-b/(2*dx))
            
             #R3i/p_{i+1}
            row_indices.append(2*len(x)+ii)
            col_indices.append(len(x)+ii+1)
            values.append(b/(2*dx))
            
            #R3i/u_{i-1}
            row_indices.append(2*len(x)+ii)
            col_indices.append(2*len(x)+ii-1)
            values.append( -(E*(1-nu))/(dx**2*(1+nu)*(1-2*nu)))
            
            #R3i/ui
            row_indices.append(2*len(x)+ii)
            col_indices.append(2*len(x)+ii)
            values.append( 2*(E*(1-nu))/(dx**2*(1+nu)*(1-2*nu)))
            
            #R3i/u_{i+1}
            row_indices.append(2*len(x)+ii)
            col_indices.append(2*len(x)+ii+1)
            values.append( -(E*(1-nu))/(dx**2*(1+nu)*(1-2*nu)))
            
 
  # Create the sparse matrix in COO format
        J_sparse = coo_matrix((values, (row_indices, col_indices)), shape=(3*len(x), 3*len(x)))

  # Optionally, convert it to CSR format for efficient row-based operations
        J_csr = J_sparse.tocsr()
        J=J_csr
        R = np.hstack([R1, R2, R3])

## Preconditionning Jacobi
        # data = np.diag(J.toarray())
        # Ival = np.arange(0, 3 * len(x))
        # Jval = Ival
        # Precond_Jacobi = csr_matrix((1./data, (Ival, Jval)), shape=(3 * len(x), 3 * len(x)))
        # Solve the system J * delta_x = -R
        #delta   = spsolve(np.dot(Precond, J), np.dot(Precond.toarray(),-R))
 
    ## Preconditionning Gauss Seidel
        # Ival = np.arange(0, 3 * len(x))
        # Jval = Ival
        # tri_lower_diag = np.tril(J.toarray(), k=1)
        # Precond_Gauss_Seidel = np.diag(data) + tri_lower_diag 

    
    ## Preconditionning with ILU GMRS       
        #Precond = spilu(J, drop_tol = 1e-10, fill_factor=1e6)
        #L1 = Precond.L.toarray()
        #U = Precond.U.toarray()
        #Precond = np.dot(L1,U)
        # Xinit_GMRES = np.hstack([T_new, p_new, u_new])
        # delta, exitCode = gmres(J, -R, x0=Xinit_GMRES, tol=1e-10,restart=None, maxiter=1000, M = Precond_Jacobi, callback=None, atol=None, callback_type=None)
        # Res_gmres= -R-J*delta
        # norm_Res_gmres = np.linalg.norm(Res_gmres)
        # norm_relative_res_GMRES = norm_Res_gmres/np.linalg.norm(-R)
        # print('Norm of relative Res gmres is {} at Newton iter {}'.format(norm_relative_res_GMRES, iter + 1))
        
   ###  Direct solver ######
        delta = spsolve(J,-R)
        
        delta_T = delta[: len(x)]
        delta_p = delta[len(x) :2*len(x)]  
        delta_u = delta[2*len(x) :]
        
       

  # Check for convergence
        norm_newton_error[iter + 1] =  np.linalg.norm(delta)
        print("Norm of Newton error at iter {} is {}".format(iter + 1, norm_newton_error[iter + 1]))

        if norm_newton_error[iter + 1] < tol:
            converged = True
            print("Newton converged at time step {} after {} iterations and norm is {}".format(nn + 1, iter + 1, norm_newton_error[iter + 1]))     
            
            norm_newton_error = norm_newton_error[0 : iter + 1]

            break
       

         
       # Update p and T
           
        T_new = T_new +  delta_T
        p_new = p_new +  delta_p
        u_new = u_new + delta_u
# # Update solution for next time step
    T[:, nn+1] = T_new
    p[:, nn+1] = p_new
    u[:, nn+1] = u_new
  
    
    if not converged:
      print("Newton method did not converge at time step {} after {} iterations and error is {}".format(nn, max_iter_newton, np.linalg.norm(delta)))     
                


#Plotting the results
time_steps_to_plot = [0,Nt//16,Nt//8, Nt//4,  Nt//2, 3*Nt//4, Nt]  # Different times to compare

for n in time_steps_to_plot:
    plt.figure(figsize=(12, 5))

    # Plot for T(x,t)
    plt.subplot(1, 4, 1)
    plt.plot(x, T[:, n], label='Numerical T', marker='o', linestyle='--')
    plt.plot(x, exact_T(x, t[n]), label='Exact T', marker='x')
    plt.xlabel('x')
    plt.ylabel('T(x,t)')
    plt.title(f'T(x,t) at t = {t[n]*t_c:.2f}')
    plt.legend()
    #file_name = "Temperature_at_time_{}_Compressible_Real_parameters_Nx=896_.pdf".format(t[n])
    #plt.savefig(os.path.join(directory2, file_name))
    # Plot for p(x,t)
    plt.subplot(1, 4, 2)
    plt.plot(x, p[:, n], label='Numerical p', marker='o', linestyle='--')
    plt.plot(x, exact_p(x, t[n]), label='Exact p', marker='x')
    plt.xlabel('x')
    plt.ylabel('p(x,t)')
    plt.title(f'p(x,t) at t = {t[n]*t_c:.2f}')
    plt.legend()
    #file_name = "Pressure_at_time_{}_Compressible_Real_parameters_Nx=896_.pdf".format(t[n])
    #plt.savefig(os.path.join(directory2, file_name))
    
    
    plt.subplot(1, 4, 3)
    plt.plot(x, u[:, n], label='Numerical u', marker='o', linestyle='--')
    plt.plot(x, exact_u(x, t[n]), label='Exact u', marker='x')
    plt.xlabel('x')
    plt.ylabel('u(x,t)')
    plt.title(f'u(x,t) at t = {t[n]*t_c:.2f}')
    plt.legend()
 #   file_name = "Solutions_at_time_{}_Compressible_Nondimensionalized_Nx=100_L=10_TIME=1hour_P_0=4.pdf".format(t[n])
  #  plt.savefig(os.path.join(directory2, file_name))
    
    plt.tight_layout()
    plt.show()   
    
### Compute L2 time L2 space errors between exact and numerical solutions   
  
error_Linf_time_p = np.zeros(len(t));
error_Linf_time_T = np.zeros(len(t));
error_Linf_time_u = np.zeros(len(t));
for kk in range(0, len(t)-1):
      error_Linf_time_p[kk] = np.max(abs(p[:, kk] - exact_p(x, t[kk])));
      error_Linf_time_T[kk] = np.max(abs(T[:, kk] - exact_T(x, t[kk])));
      error_Linf_time_u[kk] = np.max(abs(u[:, kk] - exact_u(x, t[kk])));
      
      
      
error_L2_p = np.zeros((len(x),len(t)));
integral_elem_p = np.zeros(len(x));
error_L2_each_time_p = np.zeros(len(t));
error_L2_each_elem_p = np.zeros(len(x));

exact_L2_p = np.zeros((len(x),len(t)));
exact_integral_elem_p = np.zeros(len(x));
exact_L2_each_time_p = np.zeros(len(t));
exact_L2_each_elem_p = np.zeros(len(x));


error_L2_T = np.zeros((len(x),len(t)));
integral_elem_T = np.zeros(len(x));
error_L2_each_time_T = np.zeros(len(t));
error_L2_each_elem_T = np.zeros(len(x));

exact_L2_T = np.zeros((len(x),len(t)));
exact_integral_elem_T = np.zeros(len(x));
exact_L2_each_time_T = np.zeros(len(t));
exact_L2_each_elem_T = np.zeros(len(x));


error_L2_u = np.zeros((len(x),len(t)));
integral_elem_u = np.zeros(len(x));
error_L2_each_time_u = np.zeros(len(t));
error_L2_each_elem_u = np.zeros(len(x));

exact_L2_u = np.zeros((len(x),len(t)));
exact_integral_elem_u = np.zeros(len(x));
exact_L2_each_time_u = np.zeros(len(t));
exact_L2_each_elem_u = np.zeros(len(x));

integral_elem_p_time = np.zeros(len(t));
integral_elem_T_time = np.zeros(len(t));
integral_elem_u_time = np.zeros(len(t));


integral_elem_exact_p_time = np.zeros(len(t));
integral_elem_exact_T_time = np.zeros(len(t));
integral_elem_exact_u_time = np.zeros(len(t));


relative_error_L2_p = np.zeros(len(t));
relative_error_L2_T = np.zeros(len(t));
relative_error_L2_u = np.zeros(len(t));

# Initialize arrays for relative errors


for kk in range(len(t)-1):
    error_all_elem_p = (p[:,kk] - exact_p(x, t[kk]))
    error_all_elem_square_p = error_all_elem_p ** 2

    exact_all_elem_p = exact_p(x, t[kk])
    exact_all_elem_square_p = exact_all_elem_p ** 2

    error_all_elem_T = (T[:,kk] - exact_T(x, t[kk]))
    error_all_elem_square_T = error_all_elem_T ** 2

    exact_all_elem_T = exact_T(x, t[kk])
    exact_all_elem_square_T = exact_all_elem_T ** 2

    error_all_elem_u = (u[:,kk] - exact_u(x, t[kk]))
    error_all_elem_square_u = error_all_elem_u ** 2

    exact_all_elem_u = exact_u(x, t[kk])
    exact_all_elem_square_u = exact_all_elem_u ** 2

    for ii in range(len(x) - 1):
        first_value_p = error_all_elem_square_p[ii]
        internal_value_p = error_all_elem_square_p[int((ii+ii+1)/2)]
       # internal_value_p = 0.5 * (error_all_elem_square_p[ii] + error_all_elem_square_p[ii + 1])
        last_value_p = error_all_elem_square_p[ii + 1]
        integral_elem_p[ii] = mysimpson.mysimpson(first_value_p, internal_value_p, last_value_p, dx)
        error_L2_each_elem_p[ii] = np.sqrt(integral_elem_p[ii])
        
        exact_first_value_p = exact_all_elem_square_p[ii]
        exact_internal_value_p = exact_all_elem_square_p[int((ii+ii+1)/2)]
      #  exact_internal_value_p = 0.5 * (exact_all_elem_square_p[ii] + exact_all_elem_square_p[ii + 1])
        exact_last_value_p = exact_all_elem_square_p[ii + 1]
        exact_integral_elem_p[ii] = mysimpson.mysimpson(exact_first_value_p, exact_internal_value_p, exact_last_value_p, dx)
        exact_L2_each_elem_p[ii] = np.sqrt(exact_integral_elem_p[ii])
        

        first_value_T = error_all_elem_square_T[ii]
        internal_value_T = error_all_elem_square_T[int((ii+ii+1)/2)]
       # internal_value_T = 0.5 * (error_all_elem_square_T[ii] + error_all_elem_square_T[ii + 1])
        last_value_T = error_all_elem_square_T[ii + 1]
        integral_elem_T[ii] = mysimpson.mysimpson(first_value_T, internal_value_T, last_value_T, dx)
        error_L2_each_elem_T[ii] = np.sqrt(integral_elem_T[ii])
        
        exact_first_value_T = exact_all_elem_square_T[ii]
        exact_internal_value_T = exact_all_elem_square_T[int((ii+ii+1)/2)]
       # exact_internal_value_T = 0.5 * (exact_all_elem_square_T[ii] + exact_all_elem_square_T[ii + 1])
        exact_last_value_T = exact_all_elem_square_T[ii + 1]
        exact_integral_elem_T[ii] = mysimpson.mysimpson(exact_first_value_T, exact_internal_value_T, exact_last_value_T, dx)
        exact_L2_each_elem_T[ii] = np.sqrt(exact_integral_elem_T[ii])
        

        first_value_u = error_all_elem_square_u[ii]
        internal_value_u = error_all_elem_square_u[int((ii+ii+1)/2)]
       # internal_value_u = 0.5 * (error_all_elem_square_u[ii] + error_all_elem_square_u[ii + 1])
        last_value_u = error_all_elem_square_u[ii + 1]
        integral_elem_u[ii] = mysimpson.mysimpson(first_value_u, internal_value_u, last_value_u, dx)
        error_L2_each_elem_u[ii] = np.sqrt(integral_elem_u[ii])
        
        exact_first_value_u = exact_all_elem_square_u[ii]
        exact_internal_value_u = exact_all_elem_square_u[int((ii+ii+1)/2)]
      #  exact_internal_value_u = 0.5 * (exact_all_elem_square_u[ii] + exact_all_elem_square_u[ii + 1])
        exact_last_value_u = exact_all_elem_square_u[ii + 1]
        exact_integral_elem_u[ii] = mysimpson.mysimpson(exact_first_value_u, exact_internal_value_u, exact_last_value_u, dx)
        exact_L2_each_elem_u[ii] = np.sqrt(exact_integral_elem_u[ii])

    # Compute absolute L2 errors
    error_L2_each_time_p[kk] = (np.sum(error_L2_each_elem_p**2))
    error_L2_each_time_T[kk] = (np.sum(error_L2_each_elem_T**2))
    error_L2_each_time_u[kk] = (np.sum(error_L2_each_elem_u**2))
    
    
 #   Compute L2 norm of the exact solution
    exact_L2_each_time_p[kk] = (np.sum(exact_L2_each_elem_p ** 2))
    exact_L2_each_time_T[kk] = (np.sum(exact_L2_each_elem_T ** 2))
    exact_L2_each_time_u[kk] = (np.sum(exact_L2_each_elem_u ** 2))
    
    # Compute relative errors in space
    relative_error_L2_p[kk] = np.sqrt(np.sum(error_L2_each_elem_p**2))/ np.sqrt(np.sum(exact_L2_each_elem_p ** 2)) if np.sum(exact_L2_each_elem_p ** 2) != 0 else 0
    relative_error_L2_T[kk] = np.sqrt(np.sum(error_L2_each_elem_T**2))/np.sqrt(np.sum(exact_L2_each_elem_T ** 2))  if np.sum(exact_L2_each_elem_T ** 2) != 0 else 0
    relative_error_L2_u[kk] = np.sqrt(np.sum(error_L2_each_elem_u**2))/ np.sqrt(np.sum(exact_L2_each_elem_u ** 2)) if np.sum(exact_L2_each_elem_u ** 2) != 0 else 0
    
    
    #compute space time error
    
    first_value_p_time = error_L2_each_time_p[kk]
    internal_value_p_time = error_L2_each_time_p[int((kk+kk+1)/2)]
  #  internal_value_p_time = 0.5 * (error_L2_each_time_p[kk] + error_L2_each_time_p[kk + 1])
    last_value_p_time = error_L2_each_time_p[kk + 1]
    integral_elem_p_time[kk] = mysimpson.mysimpson(first_value_p_time, internal_value_p_time, last_value_p_time, dt)
     
    
    first_value_T_time = error_L2_each_time_T[kk]
    internal_value_T_time = error_L2_each_time_T[int((kk+kk+1)/2)]
   # internal_value_T_time = 0.5 * (error_L2_each_time_T[kk] + error_L2_each_time_T[kk + 1])
    last_value_T_time = error_L2_each_time_T[kk + 1]
    integral_elem_T_time[kk] = mysimpson.mysimpson(first_value_T_time, internal_value_T_time, last_value_T_time, dt)
    
    
    first_value_u_time = error_L2_each_time_u[kk]
    internal_value_u_time = error_L2_each_time_u[int((kk+kk+1)/2)]
  #  internal_value_u_time = 0.5 * (error_L2_each_time_u[kk] + error_L2_each_time_u[kk + 1])
    last_value_u_time = error_L2_each_time_u[kk + 1]
    integral_elem_u_time[kk] = mysimpson.mysimpson(first_value_u_time, internal_value_u_time, last_value_u_time, dt)
           
    
# compute space time norm exact solution

    first_value_exact_p_time = exact_L2_each_time_p[kk]
    internal_value_exact_p_time = exact_L2_each_time_p[int((kk+kk+1)/2)]
  #  internal_value_exact_p_time = 0.5 * (exact_L2_each_time_p[kk] + exact_L2_each_time_p[kk+1])
    last_value_exact_p_time = exact_L2_each_time_p[kk+1]
    integral_elem_exact_p_time[kk] = mysimpson.mysimpson(first_value_exact_p_time, internal_value_exact_p_time, last_value_exact_p_time, dt)
     
    
    first_value_exact_T_time = exact_L2_each_time_T[kk]
    internal_value_exact_T_time = exact_L2_each_time_T[int((kk+kk+1)/2)]
   # internal_value_exact_T_time = 0.5 * (exact_L2_each_time_T[kk] + exact_L2_each_time_T[kk + 1])
    last_value_exact_T_time = exact_L2_each_time_T[kk + 1]
    integral_elem_exact_T_time[kk] = mysimpson.mysimpson(first_value_exact_T_time, internal_value_exact_T_time, last_value_exact_T_time, dt)
    
    
    first_value_exact_u_time = exact_L2_each_time_u[kk]
    internal_value_exact_u_time = exact_L2_each_time_u[int((kk+kk+1)/2)]
  #  internal_value_exact_u_time = 0.5 * (exact_L2_each_time_u[kk] + exact_L2_each_time_u[kk + 1])
    last_value_exact_u_time = exact_L2_each_time_u[kk + 1]
    integral_elem_exact_u_time[kk] = mysimpson.mysimpson(first_value_exact_u_time, internal_value_exact_u_time, last_value_exact_u_time, dt)
    

    #Norm L infty in time 
    
    error_infty_p = np.max(np.sqrt(np.sum(error_L2_each_elem_p**2)))
    error_infty_T = np.max(np.sqrt(np.sum(error_L2_each_elem_T**2)))
    error_infty_u = np.max(np.sqrt(np.sum(error_L2_each_elem_u**2)))
    
    exact_infty_p = np.max(np.sqrt(np.sum(exact_L2_each_elem_p**2)))
    exact_infty_T = np.max(np.sqrt(np.sum(exact_L2_each_elem_T**2)))
    exact_infty_u = np.max(np.sqrt(np.sum(exact_L2_each_elem_u**2)))
    
global_relative_error_L2_p = np.sqrt(np.sum(integral_elem_p_time))/np.sqrt(np.sum(integral_elem_exact_p_time))   if np.sum(integral_elem_exact_p_time) != 0 else 0
global_relative_error_L2_T = np.sqrt(np.sum(integral_elem_T_time))/np.sqrt(np.sum(integral_elem_exact_T_time))   if np.sum(integral_elem_exact_T_time) != 0 else 0
global_relative_error_L2_u = np.sqrt(np.sum(integral_elem_u_time))/np.sqrt(np.sum(integral_elem_exact_u_time))   if np.sum(integral_elem_exact_u_time) != 0 else 0

# global_error_L2_p = np.sqrt(np.sum(integral_elem_p_time))
# global_error_L2_T = np.sqrt(np.sum(integral_elem_T_time))
# global_error_L2_u = np.sqrt(np.sum(integral_elem_u_time))


global_relative_error_infty_p = error_infty_p/exact_infty_p
global_relative_error_infty_T = error_infty_T/exact_infty_T
global_relative_error_infty_u = error_infty_u/exact_infty_u

# global_error_infty_p = error_infty_p
# global_infty_T = error_infty_T
# global_error_infty_u = error_infty_u


#Data to save
#data = {'x':x, 't':t, 'p_exact': exact_p, 'T_exact':exact_T, 'u_exact':exact_u,'num_p': p,'num_T': T,'num_u': u}

# Save to a file
# with open("data_Compressible_Real_parameters_Nx=896.pkl", "wb") as file:
#     pickle.dump(data, file)

# with open("output.csv", "w", newline="") as file:
#     writer = csv.writer(file)
#     writer.writerows(data)

# Load from a file
# with open("data.pkl", "rb") as file:
#     loaded_data = pickle.load(file)

# print(loaded_data) 

#get the variables

#for key, value in loaded_data.items():
#    globals()[key] = value

### Plot  errors

plt.figure(figsize=(12, 5))
plt.subplot(1, 3, 1)
plt.semilogy(range(0, len(t)),np.sqrt(error_L2_each_time_p) , marker = 's', markersize = 6, mec = 'green', mfc = 'green', color = 'green', linewidth = 2, label = r'L2 space error for p')
plt.semilogy(range(0, len(t)), error_Linf_time_p, marker = 'd', markersize = 6, mec = 'red', mfc = 'red', color = 'red', linewidth = 2, label = r'Linf space error for p')

plt.xlabel('Time step', fontsize = 14)
plt.ylabel('Error_Pressure', fontsize = 14)
#plt.xticks(fontsize = 14)
#plt.yticks(fontsize = 14)
plt.legend(fontsize = 13)
#file_name = "Error_Pressure_Compressible_Real_parameters_Nx=896_.pdf"
#plt.savefig(os.path.join(directory2, file_name))

plt.subplot(1, 3, 2)
plt.semilogy(range(0, len(t)), np.sqrt(error_L2_each_time_T), marker = 's', markersize = 6, mec = 'green', mfc = 'green', color = 'green', linewidth = 2, label = r'L2 space error for T')
plt.semilogy(range(0, len(t)), error_Linf_time_T, marker = 'd', markersize = 6, mec = 'red', mfc = 'red', color = 'red', linewidth = 2, label = r'Linf space error for T')

plt.xlabel('Time step', fontsize = 14)
plt.ylabel('Error_Temperature', fontsize = 14)
#plt.xticks(fontsize = 14)
#plt.yticks(fontsize = 14)
plt.legend(fontsize = 13)
#file_name = "Error_Temperature_Compressible_Real_parameters_Nx=896_.pdf"
#plt.savefig(os.path.join(directory2, file_name))

plt.subplot(1, 3, 3)
plt.semilogy(range(0, len(t)), np.sqrt(error_L2_each_time_u), marker = 's', markersize = 6, mec = 'green', mfc = 'green', color = 'green', linewidth = 2, label = r'L2 space error for u')
plt.semilogy(range(0, len(t)), error_Linf_time_u, marker = 'd', markersize = 6, mec = 'red', mfc = 'red', color = 'red', linewidth = 2, label = r'Linf space error for u')

plt.xlabel('Time step', fontsize = 14)
plt.ylabel('Error_Displacement', fontsize = 14)
#plt.xticks(fontsize = 14)
#plt.yticks(fontsize = 14)
plt.legend(fontsize = 13)
file_name = "Error_Solution_Compressible_Nx=50_L=1.pdf"
plt.savefig(os.path.join(directory2, file_name))
plt.tight_layout()
plt.show()       
            


# # Animation function: this will update the plot at each time step
# def update(nn):
#     y = exact_p(x, t[nn])  # Update the function based on current time t
#     line.set_ydata(y)  # Update the line with new y-values

#     z=p[:,nn]
#     line2.set_ydata(z)
#     return line,line2,  # Return the updated line

# # Create the animation
# ani = FuncAnimation(fig, update, frames=nn, interval=0.1)
# ani.save('animation_pressure.gif', writer='pillow')  # GIF
# # Show the animation
# plt.show()



# #Animation for temperature 


# fig, ax = plt.subplots()
# #x = np.linspace(0, 20, 100)  # Spatial range
# line, = ax.plot(x, exact_T(x, 0),label='Exact Solution', color = 'blue')  # Initial plot
# line2, = ax.plot(x,T[:,0], label='Numerical Solution', color = 'red', linestyle = 'dashed')
# ax.legend()

# # Set up the axis limits
# ax.set_xlim(0, 1)
# ax.set_ylim()

# # Animation function: this will update the plot at each time step
# def update(nn):
#     y = exact_T(x, t[nn])  # Update the function based on current time t
#     line.set_ydata(y)  # Update the line with new y-values

#     z=T[:,nn]
#     line2.set_ydata(z)
#     return line,line2,  # Return the updated line

# # Create the animation
# ani = FuncAnimation(fig, update, frames=nn, interval=0.1)
# ani.save('animation_Temperature.gif', writer='pillow')  # GIF
# # Show the animation
# plt.show()


# #Animation for displacement

# fig, ax = plt.subplots()
# #x = np.linspace(0, 20, 100)  # Spatial range
# line, = ax.plot(x, exact_u(x, 0),label='Exact Solution', color = 'blue')  # Initial plot
# line2, = ax.plot(x,u[:,0], label='Numerical Solution', color = 'red', linestyle = 'dashed')
# ax.legend()

# # Set up the axis limits
# ax.set_xlim(0, 1)
# ax.set_ylim()

# # Animation function: this will update the plot at each time step
# def update(nn):
#     y = exact_u(x, t[nn])  # Update the function based on current time t
#     line.set_ydata(y)  # Update the line with new y-values

#     z=u[:,nn]
#     line2.set_ydata(z)
#     return line,line2,  # Return the updated line

# # Create the animation
# ani = FuncAnimation(fig, update, frames=nn, interval=0.1)
# ani.save('animation_Displacement.gif', writer='pillow')  # GIF
# # Show the animation
# plt.show()

end = time.time()

print(end - start)      
  
# epsilon = np.zeros((len(x),len(t)))
# epsilon[0,:] = u[1,:]/(3*dx/2)

# epsilon[len(x)-1,:] = -u[len(x)-2,:]/(3*dx/2)

# for kk in range(1, len(x)-1):
#     epsilon[kk,:] = (u[kk+1,:] - u[kk-1,:])/(2*dx)
    


# time_indices = [0,Nt//16,Nt//8, Nt//4, Nt//2, 3*Nt//4, Nt]

# plt.figure(figsize=(8, 5))

# # Plot multiple time slices in the same figure
# for idx in time_indices:
#     plt.plot(x, epsilon[:, idx], label=f't = {t[idx]*t_c:.2f}')

# plt.xlabel('x')
# plt.ylabel('epsilon(x,t)')
# plt.title('Evolution of strain tensor over time')
# plt.legend()
# plt.grid(True)
# plt.show()


# time_indices = [Nt//16,Nt//8, Nt//4, Nt//2, 3*Nt//4, Nt]

# plt.figure(figsize=(8, 5))

# # Plot multiple time slices in the same figure
# for idx in time_indices:
#     plt.plot(x, epsilon[:, idx], label=f't = {t[idx]*t_c:.2f}')

# plt.xlabel('x')
# plt.ylabel('epsilon(x,t)')
# plt.title('Evolution of strain tensor over time')
# plt.legend()
# plt.grid(True)
# plt.show()

# stress = np.zeros((len(x),len(t)))

# stress= E*(1-nu)*(epsilon)/((1+nu)*(1-2*nu)) -b*(p-p_ref) -3*alpha_s*K_s*(T-T_ref)


# time_indices = [Nt//16,Nt//8, Nt//4, Nt//2, 3*Nt//4, Nt]

# plt.figure(figsize=(8, 5))

# # Plot multiple time slices in the same figure
# for idx in time_indices:
#     plt.plot(x, stress[:, idx], label=f't = {t[idx]*t_c:.2f}')

# plt.xlabel('x')
# plt.ylabel('stress(x,t)')
# plt.title('Evolution of stress tensor over time')
# plt.legend()
# plt.grid(True)
# plt.show()

#Save data to csv file

# data_t_five_days = np.column_stack([x*L_c, p[:, 10]*P_c])  # Select only t and p for x=5

# # Save filtered data
# np.savetxt("p_t_five_days.csv", data_t_five_days, delimiter=",", header="x,p", comments='')

# data = np.column_stack([x*L_c, p[:, 1000]*P_c,T[:,1000]*T_c,u[:,1000]*u_c])  # Select only t and p for x=5

# # # Save filtered data
# np.savetxt("data_solution_incompressible_t_F_1day.csv", data, delimiter=",", header="x,p,T,u", comments='')